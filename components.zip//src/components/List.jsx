import React from "react";
import ReactDom from "react-dom";

export default function List() {
  return (
    <ol>
      <li>Apple</li>
      <li>Orange</li>
      <li>Guava</li>
    </ol>
  );
}
