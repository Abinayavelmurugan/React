import React from "react";
import ReactDom from "react-dom";
import Heading from "./Heading";
import List from "./List";
function App() {
  return (
    <div>
      <Heading />
      <List />
    </div>
  );
}
export default App;
