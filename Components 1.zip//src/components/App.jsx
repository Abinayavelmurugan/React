import React from "react";
import ReactDom from "react-dom";
import Greeting from "./Greeting";

export default function App() {
  return <Greeting />;
}
